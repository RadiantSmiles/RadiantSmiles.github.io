$('#player').youTubeEmbed({
	video			: 'http://www.youtube.com/watch?v=Q0whuwBFXH4',
	width			: 600, 		// Height is calculated automatically
	progressBar	: false		// Hide the progress bar
});
